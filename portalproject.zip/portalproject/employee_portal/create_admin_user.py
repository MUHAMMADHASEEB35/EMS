import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'employee_portal.settings')
django.setup()

from portal.models import User

def create_admin_user():
    username = 'admin'
    email = 'portal.admin.pk.@adm.com'
    password = 'Admin123'
    if not User.objects.filter(username=username).exists():
        user = User.objects.create_user(username=username, email=email, password=password)
        user.role = 'admin'
        user.save()
        print(f"Admin user created: {username} / {password}")
    else:
        # Update password if user exists
        user = User.objects.get(username=username)
        user.set_password(password)
        user.save()
        print(f"Admin user password updated: {username} / {password}")

if __name__ == '__main__':
    create_admin_user()
