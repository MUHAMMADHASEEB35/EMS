from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.http import JsonResponse
from django.db import models
from django.utils import timezone
from datetime import datetime
from .models import LeaveRequest, TransferRequest, RetirementRequest, ResignationRequest, User, Notification
from .forms import (
    AdminLeaveRequestForm, AdminTransferRequestForm, AdminRetirementRequestForm, AdminResignationRequestForm,
    LeaveRequestForm, TransferRequestForm, RetirementRequestForm, ResignationRequestForm, UserProfileForm, UserCreationForm
)

@login_required
def home(request):
    """
    Home view that redirects users to their appropriate dashboard based on their role.
    """
    if request.user.role == 'admin':
        return redirect('portal:admin_dashboard')
    elif request.user.role == 'manager':
        return redirect('portal:manager_dashboard')
    else:  # employee
        return redirect('portal:employee_dashboard')

def signup_view(request):
    """
    User registration view.
    """
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Set default role as employee
            user.role = 'employee'
            user.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('portal:home')
    else:
        form = UserCreationForm()
    return render(request, 'portal/signup.html', {'form': form})

def login_view(request):
    """
    User login view.
    """
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Welcome back, {username}!')
                return redirect('portal:home')
            else:
                messages.error(request, 'Invalid username or password.')
        else:
            messages.error(request, 'Invalid username or password.')
    else:
        form = AuthenticationForm()
    return render(request, 'portal/login_new.html', {'form': form})

def logout_view(request):
    """
    User logout view.
    """
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('portal:login')

@login_required
def employee_dashboard(request):
    """
    Employee dashboard view.
    """
    if request.user.role != 'employee':
        return redirect('portal:home')

    # Get user's requests
    leave_requests = LeaveRequest.objects.filter(user=request.user)
    transfer_requests = TransferRequest.objects.filter(user=request.user)
    retirement_requests = RetirementRequest.objects.filter(user=request.user)
    resignation_requests = ResignationRequest.objects.filter(user=request.user)

    # Calculate leave statistics
    # Monthly leave quota: 2 short leaves per month
    monthly_leave_quota = 2
    leaves_taken_month = leave_requests.filter(
        start_date__month=datetime.now().month,
        start_date__year=datetime.now().year,
        status='approved'
    ).count()
    remaining_leaves_month = max(0, monthly_leave_quota - leaves_taken_month)

    # Yearly leave quota: 20 leaves per year
    yearly_leave_quota = 20
    leaves_taken_year = leave_requests.filter(
        start_date__year=datetime.now().year,
        status='approved'
    ).count()
    remaining_leaves_year = max(0, yearly_leave_quota - leaves_taken_year)

    # Calculate transfer statistics
    transfers_done = transfer_requests.filter(status='approved').count()
    transfers_remaining = 2  # Default transfer quota per year

    # Calculate retirement/resignation statistics
    retirement_pending = retirement_requests.filter(status='pending').count()
    retirement_approved = retirement_requests.filter(status='approved').count()
    retirement_rejected = retirement_requests.filter(status='rejected').count()

    # Calculate resignation statistics
    resignation_pending = resignation_requests.filter(status='pending').count()
    resignation_approved = resignation_requests.filter(status='approved').count()
    resignation_rejected = resignation_requests.filter(status='rejected').count()

    # Calculate short leaves count
    short_leaves_count = leave_requests.filter(
        leave_type='Short Leave',
        status='approved'
    ).count()

    # Calculate years to retirement (placeholder calculations)
    years_to_retirement_birth = None
    years_to_retirement_service = None

    if hasattr(request.user, 'date_of_birth') and request.user.date_of_birth:
        today = datetime.now().date()
        birth_date = request.user.date_of_birth
        age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
        years_to_retirement_birth = max(0, 60 - age)  # Assuming retirement age is 60

    if hasattr(request.user, 'date_of_joining') and request.user.date_of_joining:
        today = datetime.now().date()
        joining_date = request.user.date_of_joining
        service_years = today.year - joining_date.year - ((today.month, today.day) < (joining_date.month, joining_date.day))
        years_to_retirement_service = max(0, 30 - service_years)  # Assuming 30 years service for retirement

    context = {
        'leave_requests': leave_requests,
        'transfer_requests': transfer_requests,
        'retirement_requests': retirement_requests,
        'resignation_requests': resignation_requests,
        'remaining_leaves_month': remaining_leaves_month,
        'leaves_taken_year': leaves_taken_year,
        'remaining_leaves_year': remaining_leaves_year,
        'transfers_done': transfers_done,
        'transfers_remaining': transfers_remaining,
        'retirement_pending': retirement_pending,
        'retirement_approved': retirement_approved,
        'retirement_rejected': retirement_rejected,
        'resignation_pending': resignation_pending,
        'resignation_approved': resignation_approved,
        'resignation_rejected': resignation_rejected,
        'short_leaves_count': short_leaves_count,
        'years_to_retirement_birth': years_to_retirement_birth,
        'years_to_retirement_service': years_to_retirement_service,
    }
    return render(request, 'portal/employee_dashboard.html', context)

@login_required
def manager_dashboard(request):
    """
    Manager dashboard view.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    # Get assigned requests
    assigned_leave = LeaveRequest.objects.filter(assigned_manager=request.user)
    assigned_transfer = TransferRequest.objects.filter(assigned_manager=request.user)
    assigned_retirement = RetirementRequest.objects.filter(assigned_manager=request.user)

    # Check if we should show dashboard or specific category
    selected_category = request.GET.get('category', 'dashboard')
    search_pl_no = request.GET.get('search_pl_no', '')

    if selected_category != 'dashboard':
        show_dashboard = False
        if selected_category == 'leave':
            requests = assigned_leave.filter(user__pl_no__icontains=search_pl_no) if search_pl_no else assigned_leave
        elif selected_category == 'transfer':
            requests = assigned_transfer.filter(user__pl_no__icontains=search_pl_no) if search_pl_no else assigned_transfer
        elif selected_category == 'retirement':
            requests = assigned_retirement.filter(user__pl_no__icontains=search_pl_no) if search_pl_no else assigned_retirement
        else:
            requests = []
    else:
        show_dashboard = True
        requests = []

    # Calculate statistics for dashboard
    pending_counts = {
        'short_leave': assigned_leave.filter(status='pending').count(),
        'other_leave': assigned_leave.filter(status='pending').count(),
        'transfer': assigned_transfer.filter(status='pending').count(),
        'retirement': assigned_retirement.filter(status='pending').count(),
    }

    context = {
        'assigned_leave': assigned_leave,
        'assigned_transfer': assigned_transfer,
        'assigned_retirement': assigned_retirement,
        'show_dashboard': show_dashboard,
        'selected_category': selected_category,
        'search_pl_no': search_pl_no,
        'requests': requests,
        'pending_counts': pending_counts,
    }
    return render(request, 'portal/manager_dashboard.html', context)

@login_required
def admin_dashboard(request):
    """
    Admin dashboard view.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get only pending requests (exclude approved/rejected)
    all_leave = LeaveRequest.objects.filter(status__in=['pending', 'submitted'])
    all_transfer = TransferRequest.objects.filter(status__in=['pending', 'submitted'])
    all_retirement = RetirementRequest.objects.filter(status__in=['pending', 'submitted'])
    all_resignation = ResignationRequest.objects.filter(status__in=['pending', 'submitted'])
    all_users = User.objects.all()

    # Calculate statistics
    total_users = all_users.count()
    num_managers = all_users.filter(role='manager').count()
    num_employees = all_users.filter(role='employee').count()

    # Calculate request counts
    leave_requests_total = all_leave.count()
    transfer_requests_total = all_transfer.count()
    retirement_requests_total = all_retirement.count()
    resignation_requests_total = all_resignation.count()
    total_requests = leave_requests_total + transfer_requests_total + retirement_requests_total + resignation_requests_total

    # Calculate pending counts
    pending_counts = {
        'leave': all_leave.filter(status='pending').count(),
        'transfer': all_transfer.filter(status='pending').count(),
        'retirement': all_retirement.filter(status='pending').count(),
        'resignation': all_resignation.filter(status='pending').count(),
    }

    # Calculate approved counts
    approved_counts = {
        'leave': all_leave.filter(status='approved').count(),
        'transfer': all_transfer.filter(status='approved').count(),
        'retirement': all_retirement.filter(status='approved').count(),
        'resignation': all_resignation.filter(status='approved').count(),
    }

    # Calculate completed and pending totals
    completed = sum(approved_counts.values())
    pending = sum(pending_counts.values())

    # Calculate users on leave (users with approved leave requests)
    users_on_leave = all_leave.filter(status='approved').values('user').distinct().count()

    # Calculate daily orders (total pending requests)
    daily_orders = pending

    # Prepare pie chart data
    pie_chart_data = [leave_requests_total, transfer_requests_total, retirement_requests_total, resignation_requests_total]

    # Prepare progress pie data
    progress_pie_data = [completed, pending]

    # Prepare daily orders per month (simplified - would need actual date calculations)
    daily_orders_per_month = [daily_orders] * 12  # Placeholder data

    # Check if we should show dashboard or specific category
    selected_category = request.GET.get('category', '')
    search_pl_no = request.GET.get('search_pl_no', '')

    if selected_category:
        show_dashboard = False
        if selected_category == 'leave':
            requests = all_leave.filter(user__pl_no__icontains=search_pl_no) if search_pl_no else all_leave
        elif selected_category == 'transfer':
            requests = all_transfer.filter(user__pl_no__icontains=search_pl_no) if search_pl_no else all_transfer
        elif selected_category == 'retirement':
            requests = all_retirement.filter(user__pl_no__icontains=search_pl_no) if search_pl_no else all_retirement
        else:
            requests = []
    else:
        show_dashboard = True
        requests = []

    context = {
        'all_leave': all_leave,
        'all_transfer': all_transfer,
        'all_retirement': all_retirement,
        'all_users': all_users,
        'show_dashboard': show_dashboard,
        'selected_category': selected_category,
        'search_pl_no': search_pl_no,
        'requests': requests,
        'total_users': total_users,
        'users_on_leave': users_on_leave,
        'num_managers': num_managers,
        'num_employees': num_employees,
        'pending_counts': pending_counts,
        'approved_counts': approved_counts,
        'daily_orders': daily_orders,
        'completed': completed,
        'pending': pending,
        'total_requests': total_requests,
        'leave_requests_total': leave_requests_total,
        'transfer_requests_total': transfer_requests_total,
        'retirement_requests_total': retirement_requests_total,
        'resignation_requests_total': resignation_requests_total,
        'pie_chart_data': pie_chart_data,
        'progress_pie_data': progress_pie_data,
        'daily_orders_per_month': daily_orders_per_month,
    }
    return render(request, 'portal/admin_dashboard.html', context)

@login_required
def new_leave_request(request):
    """
    Create new leave request.
    """
    if request.user.role != 'employee':
        return redirect('portal:home')

    if request.method == 'POST':
        form = LeaveRequestForm(request.POST)
        if form.is_valid():
            leave_request = form.save(commit=False)
            leave_request.user = request.user
            leave_request.save()
            messages.success(request, 'Leave request submitted successfully!')
            return redirect('portal:employee_dashboard')
    else:
        form = LeaveRequestForm()

    return render(request, 'portal/new_leave_request.html', {'form': form})

@login_required
def new_transfer_request(request):
    """
    Create new transfer request.
    """
    if request.user.role != 'employee':
        return redirect('portal:home')

    if request.method == 'POST':
        form = TransferRequestForm(request.POST)
        if form.is_valid():
            transfer_request = form.save(commit=False)
            transfer_request.user = request.user
            transfer_request.save()
            messages.success(request, 'Transfer request submitted successfully!')
            return redirect('portal:employee_dashboard')
    else:
        form = TransferRequestForm()

    return render(request, 'portal/new_transfer_request.html', {'form': form})

@login_required
def new_retirement_request(request):
    """
    Create new retirement request.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    if request.method == 'POST':
        form = RetirementRequestForm(request.POST)
        if form.is_valid():
            retirement_request = form.save(commit=False)
            retirement_request.user = request.user
            retirement_request.save()
            messages.success(request, 'Retirement request submitted successfully!')
            return redirect('portal:employee_dashboard')
    else:
        form = RetirementRequestForm()

    return render(request, 'portal/new_retirement_request.html', {'form': form})

@login_required
def employee_request_history(request):
    """
    View employee request history.
    """
    if request.user.role != 'employee':
        return redirect('portal:home')

    # Get selected category from GET parameters
    selected_category = request.GET.get('category', 'all')

    # Fetch all requests for the user
    leave_requests = LeaveRequest.objects.filter(user=request.user)
    transfer_requests = TransferRequest.objects.filter(user=request.user)
    retirement_requests = RetirementRequest.objects.filter(user=request.user)
    resignation_requests = ResignationRequest.objects.filter(user=request.user)

    # Combine all requests into a single list and order by creation date (newest first)
    all_requests = list(leave_requests) + list(transfer_requests) + list(retirement_requests) + list(resignation_requests)
    all_requests.sort(key=lambda x: x.created_at, reverse=True)

    # Filter based on selected category
    if selected_category == 'leave':
        requests = leave_requests
    elif selected_category == 'transfer':
        requests = transfer_requests
    elif selected_category == 'retirement':
        requests = retirement_requests
    elif selected_category == 'resignation':
        requests = resignation_requests
    else:  # 'all' or default
        requests = all_requests

    context = {
        'requests': requests,
        'selected_category': selected_category,
    }
    return render(request, 'portal/employee_request_history.html', context)

@login_required
def manager_request_history(request):
    """
    View manager request history.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    # Get selected category from GET parameters
    selected_category = request.GET.get('category', 'all')

    # Fetch all requests assigned to the manager
    leave_requests = LeaveRequest.objects.filter(assigned_manager=request.user)
    transfer_requests = TransferRequest.objects.filter(assigned_manager=request.user)
    retirement_requests = RetirementRequest.objects.filter(assigned_manager=request.user)

    # Combine all requests into a single list and order by creation date (newest first)
    all_requests = list(leave_requests) + list(transfer_requests) + list(retirement_requests)
    all_requests.sort(key=lambda x: x.created_at, reverse=True)

    # Filter based on selected category
    if selected_category == 'leave':
        requests = leave_requests
    elif selected_category == 'transfer':
        requests = transfer_requests
    elif selected_category == 'retirement':
        requests = retirement_requests
    else:  # 'all' or default
        requests = all_requests

    context = {
        'requests': requests,
        'selected_category': selected_category,
    }
    return render(request, 'portal/manager_request_history.html', context)

@login_required
def download_requests_excel(request):
    """
    Download employee requests as Excel.
    """
    if request.user.role != 'employee':
        return redirect('portal:home')

    # This is a placeholder - would need additional libraries for Excel generation
    messages.info(request, 'Excel download feature coming soon!')
    return redirect('portal:employee_request_history')

@login_required
def personal_information(request):
    """
    View and edit personal information.
    """
    if request.method == 'POST':
        # Handle form submission for updating personal info
        messages.success(request, 'Personal information updated successfully!')
        return redirect('portal:personal_information')

    context = {'user': request.user}
    return render(request, 'portal/personal_information.html', context)

@login_required
def manager_approve_request(request, request_id):
    """
    Manager approves a request.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    try:
        # Get the request based on ID - try different models
        request_obj = None
        request_type = None

        # Try to find the request in different models
        for model in [LeaveRequest, TransferRequest, RetirementRequest, ResignationRequest]:
            try:
                request_obj = model.objects.get(id=request_id)
                request_type = model.__name__.lower().replace('request', '')
                break
            except model.DoesNotExist:
                continue

        if not request_obj:
            messages.error(request, 'Request not found.')
            return redirect('portal:manager_dashboard')

        # Check if the request is assigned to this manager
        if request_obj.assigned_manager != request.user:
            messages.error(request, 'You are not authorized to approve this request.')
            return redirect('portal:manager_dashboard')

        # Update the request status
        request_obj.status = 'approved'
        request_obj.save()

        # Create notification for the employee
        create_notification(
            user=request_obj.user,
            notification_type='request_approved',
            title='Request Approved',
            message=f'Your {request_type} request has been approved by your manager.',
            related_object_type=request_type,
            related_object_id=request_id
        )

        # Send notifications to all admins
        admins = User.objects.filter(role='admin')
        for admin in admins:
            create_notification(
                user=admin,
                notification_type='request_approved',
                title='Request Approved by Manager',
                message=f'Manager {request.user.username} approved a {request_type} request from {request_obj.user.username}.',
                related_object_type=request_type,
                related_object_id=request_id
            )

        messages.success(request, f'Request {request_id} approved successfully!')
        return redirect('portal:manager_dashboard')

    except Exception as e:
        messages.error(request, f'Error approving request: {str(e)}')
        return redirect('portal:manager_dashboard')

@login_required
def manager_reject_request(request, request_id):
    """
    Manager rejects a request.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    try:
        # Get the request based on ID - try different models
        request_obj = None
        request_type = None

        # Try to find the request in different models
        for model in [LeaveRequest, TransferRequest, RetirementRequest, ResignationRequest]:
            try:
                request_obj = model.objects.get(id=request_id)
                request_type = model.__name__.lower().replace('request', '')
                break
            except model.DoesNotExist:
                continue

        if not request_obj:
            messages.error(request, 'Request not found.')
            return redirect('portal:manager_dashboard')

        # Check if the request is assigned to this manager
        if request_obj.assigned_manager != request.user:
            messages.error(request, 'You are not authorized to reject this request.')
            return redirect('portal:manager_dashboard')

        # Update the request status
        request_obj.status = 'rejected'
        request_obj.save()

        # Create notification for the employee
        create_notification(
            user=request_obj.user,
            notification_type='request_rejected',
            title='Request Rejected',
            message=f'Your {request_type} request has been rejected by your manager.',
            related_object_type=request_type,
            related_object_id=request_id
        )

        # Send notifications to all admins
        admins = User.objects.filter(role='admin')
        for admin in admins:
            create_notification(
                user=admin,
                notification_type='request_rejected',
                title='Request Rejected by Manager',
                message=f'Manager {request.user.username} rejected a {request_type} request from {request_obj.user.username}.',
                related_object_type=request_type,
                related_object_id=request_id
            )

        messages.success(request, f'Request {request_id} rejected successfully.')
        return redirect('portal:manager_dashboard')

    except Exception as e:
        messages.error(request, f'Error rejecting request: {str(e)}')
        return redirect('portal:manager_dashboard')

@login_required
def manager_submit_request(request, request_id):
    """
    Manager submits a request for higher approval.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    # This is a placeholder implementation
    messages.success(request, f'Request {request_id} submitted for approval.')
    return redirect('portal:manager_dashboard')

@login_required
def admin_approve_request(request, request_id):
    """
    Admin approves a request.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    try:
        # Get the request based on ID - try different models
        request_obj = None
        request_type = None

        # Try to find the request in different models
        for model in [LeaveRequest, TransferRequest, RetirementRequest, ResignationRequest]:
            try:
                request_obj = model.objects.get(id=request_id)
                request_type = model.__name__.lower().replace('request', '')
                break
            except model.DoesNotExist:
                continue

        if not request_obj:
            messages.error(request, 'Request not found.')
            return redirect('portal:admin_dashboard')

        # Update the request status
        request_obj.status = 'approved'
        request_obj.save()

        # Create notification for the employee
        create_notification(
            user=request_obj.user,
            notification_type='request_approved',
            title='Request Approved',
            message=f'Your {request_type} request has been approved by the administrator.',
            related_object_type=request_type,
            related_object_id=request_id
        )

        # Send notifications to all managers
        managers = User.objects.filter(role='manager')
        for manager in managers:
            create_notification(
                user=manager,
                notification_type='request_approved',
                title='Request Approved by Admin',
                message=f'Administrator approved a {request_type} request from {request_obj.user.username}.',
                related_object_type=request_type,
                related_object_id=request_id
            )

        messages.success(request, f'Request {request_id} approved successfully!')
        return redirect('portal:admin_dashboard')

    except Exception as e:
        messages.error(request, f'Error approving request: {str(e)}')
        return redirect('portal:admin_dashboard')

@login_required
def admin_reject_request(request, request_id):
    """
    Admin rejects a request.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    try:
        # Get the request based on ID - try different models
        request_obj = None
        request_type = None

        # Try to find the request in different models
        for model in [LeaveRequest, TransferRequest, RetirementRequest, ResignationRequest]:
            try:
                request_obj = model.objects.get(id=request_id)
                request_type = model.__name__.lower().replace('request', '')
                break
            except model.DoesNotExist:
                continue

        if not request_obj:
            messages.error(request, 'Request not found.')
            return redirect('portal:admin_dashboard')

        # Update the request status
        request_obj.status = 'rejected'
        request_obj.save()

        # Create notification for the employee
        create_notification(
            user=request_obj.user,
            notification_type='request_rejected',
            title='Request Rejected',
            message=f'Your {request_type} request has been rejected by the administrator.',
            related_object_type=request_type,
            related_object_id=request_id
        )

        # Send notifications to all managers
        managers = User.objects.filter(role='manager')
        for manager in managers:
            create_notification(
                user=manager,
                notification_type='request_rejected',
                title='Request Rejected by Admin',
                message=f'Administrator rejected a {request_type} request from {request_obj.user.username}.',
                related_object_type=request_type,
                related_object_id=request_id
            )

        messages.success(request, f'Request {request_id} rejected successfully.')
        return redirect('portal:admin_dashboard')

    except Exception as e:
        messages.error(request, f'Error rejecting request: {str(e)}')
        return redirect('portal:admin_dashboard')

@login_required
def admin_create_leave_request(request):
    """
    Admin creates a leave request.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    if request.method == 'POST':
        form = AdminLeaveRequestForm(request.POST)
        if form.is_valid():
            leave_request = form.save(commit=False)
            leave_request.status = 'approved'  # Auto-approved by admin
            leave_request.save()
            messages.success(request, 'Leave request created and approved.')
            return redirect('portal:admin_dashboard')
    else:
        form = AdminLeaveRequestForm()

    return render(request, 'portal/admin_create_leave_request.html', {'form': form})

@login_required
def admin_create_transfer_request(request):
    """
    Admin creates a transfer request.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    if request.method == 'POST':
        form = AdminTransferRequestForm(request.POST)
        if form.is_valid():
            transfer_request = form.save(commit=False)
            transfer_request.status = 'approved'  # Auto-approved by admin
            transfer_request.save()
            messages.success(request, 'Transfer request created and approved.')
            return redirect('portal:admin_dashboard')
    else:
        form = AdminTransferRequestForm()

    return render(request, 'portal/admin_create_transfer_request.html', {'form': form})

@login_required
def admin_create_retirement_request(request):
    """
    Admin creates a retirement request.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    if request.method == 'POST':
        form = AdminRetirementRequestForm(request.POST)
        if form.is_valid():
            retirement_request = form.save(commit=False)
            retirement_request.status = 'approved'  # Auto-approved by admin
            retirement_request.save()
            messages.success(request, 'Retirement request created and approved.')
            return redirect('portal:admin_dashboard')
    else:
        form = AdminRetirementRequestForm()

    return render(request, 'portal/admin_create_retirement_request.html', {'form': form})

@login_required
def search_users(request):
    """
    AJAX view to search users by name for admin request creation.
    """
    if request.user.role != 'admin':
        return JsonResponse({'error': 'Unauthorized'}, status=403)

    query = request.GET.get('q', '')
    if len(query) < 2:
        return JsonResponse({'users': []})

    try:
        # Search users by username or first/last name (assuming User model has first_name, last_name)
        users = User.objects.filter(
            models.Q(username__icontains=query) |
            models.Q(first_name__icontains=query) |
            models.Q(last_name__icontains=query)
        ).exclude(role='admin').exclude(is_superuser=True)[:5]  # Limit results to 5 and exclude admin users and superusers

        users_data = []
        for user in users:
            users_data.append({
                'id': user.id,
                'username': user.username,
                'pl_no': user.pl_no or '',
                'role': user.role,
                'department': user.department or '',
                'designation': user.designation or '',
                'display_name': f"{user.username} ({user.role})"
            })

        return JsonResponse({'users': users_data})

    except Exception as e:
        # Log the error for debugging
        print(f"Error in search_users: {str(e)}")
        return JsonResponse({'error': 'Internal server error'}, status=500)

@login_required
def edit_profile(request):
    """
    Edit user profile including PL No.
    """
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            user = form.save(commit=False)
            # Auto-generate PL No if not provided
            if not user.pl_no and user.username:
                user.pl_no = user.generate_pl_no()
            user.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('portal:personal_information')
    else:
        form = UserProfileForm(instance=request.user)

    # Get PL No suggestions for datalist
    pl_no_suggestions = []
    if request.user.pl_no:
        pl_no_suggestions.append(request.user.pl_no)

    # Add some common PL No patterns as suggestions
    if request.user.username:
        username_part = request.user.username[:3].upper()
        pl_no_suggestions.extend([
            f"EMP{username_part}1001",
            f"EMP{username_part}1002",
            f"EMP{username_part}1003",
        ])

    context = {
        'form': form,
        'pl_no_suggestions': pl_no_suggestions,
    }
    return render(request, 'portal/edit_profile.html', context)

@login_required
def admin_request_management(request):
    """
    Enhanced admin dashboard showing requests that need admin attention or override opportunities.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get all requests with manager decisions that can be overridden
    leave_requests = LeaveRequest.objects.filter(
        status__in=['approved', 'rejected'],
        admin_override_status='none'
    ).exclude(assigned_manager__isnull=True)

    transfer_requests = TransferRequest.objects.filter(
        status__in=['approved', 'rejected'],
        admin_override_status='none'
    ).exclude(assigned_manager__isnull=True)

    retirement_requests = RetirementRequest.objects.filter(
        status__in=['approved', 'rejected'],
        admin_override_status='none'
    ).exclude(assigned_manager__isnull=True)

    # Get requests that have been overridden by admin
    overridden_leave = LeaveRequest.objects.filter(admin_override_status__in=['overridden_approved', 'overridden_rejected'])
    overridden_transfer = TransferRequest.objects.filter(admin_override_status__in=['overridden_approved', 'overridden_rejected'])
    overridden_retirement = RetirementRequest.objects.filter(admin_override_status__in=['overridden_approved', 'overridden_rejected'])

    # Get pending requests that haven't been assigned to managers yet
    pending_leave = LeaveRequest.objects.filter(status='pending', assigned_manager__isnull=True)
    pending_transfer = TransferRequest.objects.filter(status='pending', assigned_manager__isnull=True)
    pending_retirement = RetirementRequest.objects.filter(status='pending', assigned_manager__isnull=True)

    context = {
        'leave_requests': leave_requests,
        'transfer_requests': transfer_requests,
        'retirement_requests': retirement_requests,
        'overridden_leave': overridden_leave,
        'overridden_transfer': overridden_transfer,
        'overridden_retirement': overridden_retirement,
        'pending_leave': pending_leave,
        'pending_transfer': pending_transfer,
        'pending_retirement': pending_retirement,
    }
    return render(request, 'portal/admin_request_management.html', context)

@login_required
def admin_override_request(request, request_type, request_id):
    """
    View for admin to override a manager's decision on a request.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get the request based on type and ID
    if request_type == 'leave':
        request_obj = LeaveRequest.objects.get(id=request_id)
    elif request_type == 'transfer':
        request_obj = TransferRequest.objects.get(id=request_id)
    elif request_type == 'retirement':
        request_obj = RetirementRequest.objects.get(id=request_id)
    else:
        messages.error(request, 'Invalid request type.')
        return redirect('portal:admin_request_management')

    if request.method == 'POST':
        override_reason = request.POST.get('override_reason')
        override_action = request.POST.get('override_action')

        if not override_reason:
            messages.error(request, 'Override reason is required.')
            return render(request, 'portal/admin_override_form.html', {'request_obj': request_obj})

        # Update the request with admin override
        from django.utils import timezone
        request_obj.admin_override_status = f'overridden_{override_action}'
        request_obj.admin_override_reason = override_reason
        request_obj.admin_override_timestamp = timezone.now()
        request_obj.admin_override_by = request.user

        # Update the main status to match the override
        request_obj.status = override_action
        request_obj.save()

        messages.success(request, f'Request has been overridden to {override_action}.')
        return redirect('portal:admin_request_management')

    context = {
        'request_obj': request_obj,
        'request_type': request_type,
    }
    return render(request, 'portal/admin_override_form.html', context)

@login_required
def admin_view_manager_decisions(request):
    """
    View to show all manager decisions that can potentially be overridden by admin.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get all requests with manager decisions
    leave_requests = LeaveRequest.objects.filter(
        status__in=['approved', 'rejected'],
        admin_override_status='none'
    ).exclude(assigned_manager__isnull=True)

    transfer_requests = TransferRequest.objects.filter(
        status__in=['approved', 'rejected'],
        admin_override_status='none'
    ).exclude(assigned_manager__isnull=True)

    retirement_requests = RetirementRequest.objects.filter(
        status__in=['approved', 'rejected'],
        admin_override_status='none'
    ).exclude(assigned_manager__isnull=True)

    context = {
        'leave_requests': leave_requests,
        'transfer_requests': transfer_requests,
        'retirement_requests': retirement_requests,
    }
    return render(request, 'portal/admin_manager_decisions.html', context)

@login_required
def manager_create_leave_request(request):
    """
    Manager creates a leave request on behalf of an employee.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    if request.method == 'POST':
        form = LeaveRequestForm(request.POST)
        if form.is_valid():
            leave_request = form.save(commit=False)
            leave_request.status = 'pending'  # Manager-created requests need admin approval
            leave_request.save()
            messages.success(request, 'Leave request created and sent for admin approval.')
            return redirect('portal:manager_dashboard')
    else:
        form = LeaveRequestForm()

    return render(request, 'portal/new_leave_request.html', {'form': form})

@login_required
def manager_create_transfer_request(request):
    """
    Manager creates a transfer request on behalf of an employee.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    if request.method == 'POST':
        form = TransferRequestForm(request.POST)
        if form.is_valid():
            transfer_request = form.save(commit=False)
            transfer_request.status = 'pending'  # Manager-created requests need admin approval
            transfer_request.save()
            messages.success(request, 'Transfer request created and sent for admin approval.')
            return redirect('portal:manager_dashboard')
    else:
        form = TransferRequestForm()

    return render(request, 'portal/new_transfer_request.html', {'form': form})

@login_required
def manager_create_retirement_request(request):
    """
    Manager creates a resignation request on behalf of an employee.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    if request.method == 'POST':
        form = RetirementRequestForm(request.POST)
        if form.is_valid():
            retirement_request = form.save(commit=False)
            retirement_request.status = 'pending'  # Manager-created requests need admin approval
            retirement_request.save()
            messages.success(request, 'Resignation request created and sent for admin approval.')
            return redirect('portal:manager_dashboard')
    else:
        form = RetirementRequestForm()

    return render(request, 'portal/new_retirement_request.html', {'form': form})

@login_required
def new_resignation_request(request):
    """
    Create new resignation request.
    """
    if request.user.role != 'employee':
        return redirect('portal:home')

    if request.method == 'POST':
        form = ResignationRequestForm(request.POST)
        if form.is_valid():
            resignation_request = form.save(commit=False)
            resignation_request.user = request.user
            resignation_request.save()
            messages.success(request, 'Resignation request submitted successfully!')
            return redirect('portal:employee_dashboard')
    else:
        form = ResignationRequestForm()

    return render(request, 'portal/new_resignation_request.html', {'form': form})

@login_required
def admin_create_resignation_request(request):
    """
    Admin creates a resignation request.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    if request.method == 'POST':
        form = AdminResignationRequestForm(request.POST)
        if form.is_valid():
            resignation_request = form.save(commit=False)
            resignation_request.status = 'approved'  # Auto-approved by admin
            resignation_request.save()
            messages.success(request, 'Resignation request created and approved.')
            return redirect('portal:admin_dashboard')
    else:
        form = AdminResignationRequestForm()

    return render(request, 'portal/admin_create_resignation_request.html', {'form': form})

@login_required
def manager_create_resignation_request(request):
    """
    Manager creates a resignation request on behalf of an employee.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    if request.method == 'POST':
        form = ResignationRequestForm(request.POST)
        if form.is_valid():
            resignation_request = form.save(commit=False)
            resignation_request.status = 'pending'  # Manager-created requests need admin approval
            resignation_request.save()
            messages.success(request, 'Resignation request created and sent for admin approval.')
            return redirect('portal:manager_dashboard')
    else:
        form = ResignationRequestForm()

    return render(request, 'portal/new_resignation_request.html', {'form': form})

# Notification views
@login_required
def get_notifications(request):
    """
    AJAX view to get user notifications.
    """
    notifications = Notification.objects.filter(user=request.user, is_read=False)[:10]
    notifications_data = []

    for notification in notifications:
        notifications_data.append({
            'id': notification.id,
            'title': notification.title,
            'message': notification.message,
            'notification_type': notification.notification_type,
            'created_at': notification.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'is_read': notification.is_read,
        })

    return JsonResponse({'notifications': notifications_data})

@login_required
def mark_notification_read(request, notification_id):
    """
    Mark a notification as read.
    """
    try:
        notification = Notification.objects.get(id=notification_id, user=request.user)
        notification.is_read = True
        notification.save()
        return JsonResponse({'success': True})
    except Notification.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Notification not found'})

@login_required
def mark_all_notifications_read(request):
    """
    Mark all user notifications as read.
    """
    Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
    return JsonResponse({'success': True})

@login_required
def get_notification_count(request):
    """
    AJAX view to get user notification count.
    """
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()
    return JsonResponse({'count': unread_count})

# Helper function to create notifications
def create_notification(user, notification_type, title, message, related_object_type=None, related_object_id=None):
    """
    Helper function to create notifications.
    """
    Notification.objects.create(
        user=user,
        notification_type=notification_type,
        title=title,
        message=message,
        related_object_type=related_object_type,
        related_object_id=related_object_id
    )

@login_required
def admin_request_dashboard(request):
    """
    Comprehensive admin request dashboard showing all requests in a table format with filtering and search.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get only pending and submitted requests (exclude approved/rejected)
    leave_requests = LeaveRequest.objects.filter(status__in=['pending', 'submitted'])
    transfer_requests = TransferRequest.objects.filter(status__in=['pending', 'submitted'])
    retirement_requests = RetirementRequest.objects.filter(status__in=['pending', 'submitted'])

    # Combine all requests
    all_requests = list(leave_requests) + list(transfer_requests) + list(retirement_requests)
    all_requests.sort(key=lambda x: x.created_at, reverse=True)

    # Get filter parameters
    search_pl_no = request.GET.get('search_pl_no', '')
    status_filter = request.GET.get('status', '')
    category_filter = request.GET.get('category', '')

    # Apply filters
    if search_pl_no:
        all_requests = [req for req in all_requests if req.user.pl_no and search_pl_no.lower() in req.user.pl_no.lower()]

    if status_filter:
        all_requests = [req for req in all_requests if req.status == status_filter]

    if category_filter and category_filter != 'all':
        if category_filter == 'leave':
            all_requests = [req for req in all_requests if hasattr(req, 'leave_type')]
        elif category_filter == 'transfer':
            all_requests = [req for req in all_requests if hasattr(req, 'current_department')]
        elif category_filter == 'retirement':
            all_requests = [req for req in all_requests if hasattr(req, 'retirement_date')]

    # Calculate statistics
    total_requests = len(all_requests)
    pending_requests = len([req for req in all_requests if req.status == 'pending'])
    approved_requests = len([req for req in all_requests if req.status == 'approved'])
    rejected_requests = len([req for req in all_requests if req.status == 'rejected'])

    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(all_requests, 10)  # 10 requests per page
    page_number = request.GET.get('page')
    requests = paginator.get_page(page_number)

    context = {
        'requests': requests,
        'search_pl_no': search_pl_no,
        'status_filter': status_filter,
        'category_filter': category_filter,
        'total_requests': total_requests,
        'pending_requests': pending_requests,
        'approved_requests': approved_requests,
        'rejected_requests': rejected_requests,
    }
    return render(request, 'portal/admin_request_dashboard.html', context)

@login_required
def admin_leave_requests(request):
    """
    Admin dashboard for leave requests only.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get only pending leave requests (exclude approved/rejected)
    leave_requests = LeaveRequest.objects.filter(status__in=['pending', 'submitted']).order_by('-created_at')

    # Get filter parameters
    search_pl_no = request.GET.get('search_pl_no', '')
    status_filter = request.GET.get('status', '')

    # Apply filters
    if search_pl_no:
        leave_requests = leave_requests.filter(user__pl_no__icontains=search_pl_no)

    if status_filter:
        leave_requests = leave_requests.filter(status=status_filter)

    # Calculate statistics
    total_requests = leave_requests.count()
    pending_requests = leave_requests.filter(status='pending').count()
    approved_requests = leave_requests.filter(status='approved').count()
    rejected_requests = leave_requests.filter(status='rejected').count()

    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(leave_requests, 10)  # 10 requests per page
    page_number = request.GET.get('page')
    requests = paginator.get_page(page_number)

    context = {
        'requests': requests,
        'search_pl_no': search_pl_no,
        'status_filter': status_filter,
        'total_requests': total_requests,
        'pending_requests': pending_requests,
        'approved_requests': approved_requests,
        'rejected_requests': rejected_requests,
        'selected_category': 'leave',
    }
    return render(request, 'portal/admin_leave_dashboard.html', context)

@login_required
def admin_transfer_requests(request):
    """
    Admin dashboard for transfer requests only.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get only pending transfer requests (exclude approved/rejected)
    transfer_requests = TransferRequest.objects.filter(status__in=['pending', 'submitted']).order_by('-created_at')

    # Get filter parameters
    search_pl_no = request.GET.get('search_pl_no', '')
    status_filter = request.GET.get('status', '')

    # Apply filters
    if search_pl_no:
        transfer_requests = transfer_requests.filter(user__pl_no__icontains=search_pl_no)

    if status_filter:
        transfer_requests = transfer_requests.filter(status=status_filter)

    # Calculate statistics
    total_requests = transfer_requests.count()
    pending_requests = transfer_requests.filter(status='pending').count()
    approved_requests = transfer_requests.filter(status='approved').count()
    rejected_requests = transfer_requests.filter(status='rejected').count()

    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(transfer_requests, 10)  # 10 requests per page
    page_number = request.GET.get('page')
    requests = paginator.get_page(page_number)

    context = {
        'requests': requests,
        'search_pl_no': search_pl_no,
        'status_filter': status_filter,
        'total_requests': total_requests,
        'pending_requests': pending_requests,
        'approved_requests': approved_requests,
        'rejected_requests': rejected_requests,
        'selected_category': 'transfer',
    }
    return render(request, 'portal/admin_transfer_dashboard.html', context)

@login_required
def admin_retirement_requests(request):
    """
    Admin dashboard for retirement requests only.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get only pending retirement requests (exclude approved/rejected)
    retirement_requests = RetirementRequest.objects.filter(status__in=['pending', 'submitted']).order_by('-created_at')

    # Get filter parameters
    search_pl_no = request.GET.get('search_pl_no', '')
    status_filter = request.GET.get('status', '')

    # Apply filters
    if search_pl_no:
        retirement_requests = retirement_requests.filter(user__pl_no__icontains=search_pl_no)

    if status_filter:
        retirement_requests = retirement_requests.filter(status=status_filter)

    # Calculate statistics
    total_requests = retirement_requests.count()
    pending_requests = retirement_requests.filter(status='pending').count()
    approved_requests = retirement_requests.filter(status='approved').count()
    rejected_requests = retirement_requests.filter(status='rejected').count()

    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(retirement_requests, 10)  # 10 requests per page
    page_number = request.GET.get('page')
    requests = paginator.get_page(page_number)

    context = {
        'requests': requests,
        'search_pl_no': search_pl_no,
        'status_filter': status_filter,
        'total_requests': total_requests,
        'pending_requests': pending_requests,
        'approved_requests': approved_requests,
        'rejected_requests': rejected_requests,
        'selected_category': 'retirement',
    }
    return render(request, 'portal/admin_retirement_dashboard.html', context)

@login_required
def admin_resignation_requests(request):
    """
    Admin dashboard for resignation requests only.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get only pending resignation requests (exclude approved/rejected)
    resignation_requests = ResignationRequest.objects.filter(status__in=['pending', 'submitted']).order_by('-created_at')

    # Get filter parameters
    search_pl_no = request.GET.get('search_pl_no', '')
    status_filter = request.GET.get('status', '')

    # Apply filters
    if search_pl_no:
        resignation_requests = resignation_requests.filter(user__pl_no__icontains=search_pl_no)

    if status_filter:
        resignation_requests = resignation_requests.filter(status=status_filter)

    # Calculate statistics
    total_requests = resignation_requests.count()
    pending_requests = resignation_requests.filter(status='pending').count()
    approved_requests = resignation_requests.filter(status='approved').count()
    rejected_requests = resignation_requests.filter(status='rejected').count()

    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(resignation_requests, 10)  # 10 requests per page
    page_number = request.GET.get('page')
    requests = paginator.get_page(page_number)

    context = {
        'requests': requests,
        'search_pl_no': search_pl_no,
        'status_filter': status_filter,
        'total_requests': total_requests,
        'pending_requests': pending_requests,
        'approved_requests': approved_requests,
        'rejected_requests': rejected_requests,
        'selected_category': 'resignation',
    }
    return render(request, 'portal/admin_resignation_dashboard.html', context)

@login_required
def admin_request_status(request):
    """
    Admin view to show comprehensive status overview of all requests in the system.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get all requests with their current status
    leave_requests = LeaveRequest.objects.all().order_by('-created_at')
    transfer_requests = TransferRequest.objects.all().order_by('-created_at')
    retirement_requests = RetirementRequest.objects.all().order_by('-created_at')

    # Calculate status counts for each request type
    leave_status_counts = {
        'pending': leave_requests.filter(status='pending').count(),
        'approved': leave_requests.filter(status='approved').count(),
        'rejected': leave_requests.filter(status='rejected').count(),
        'submitted': leave_requests.filter(status='submitted').count(),
    }

    transfer_status_counts = {
        'pending': transfer_requests.filter(status='pending').count(),
        'approved': transfer_requests.filter(status='approved').count(),
        'rejected': transfer_requests.filter(status='rejected').count(),
        'submitted': transfer_requests.filter(status='submitted').count(),
    }

    retirement_status_counts = {
        'pending': retirement_requests.filter(status='pending').count(),
        'approved': retirement_requests.filter(status='approved').count(),
        'rejected': retirement_requests.filter(status='rejected').count(),
        'submitted': retirement_requests.filter(status='submitted').count(),
    }

    # Calculate total counts
    total_requests = leave_requests.count() + transfer_requests.count() + retirement_requests.count()
    total_pending = leave_status_counts['pending'] + transfer_status_counts['pending'] + retirement_status_counts['pending']
    total_approved = leave_status_counts['approved'] + transfer_status_counts['approved'] + retirement_status_counts['approved']
    total_rejected = leave_status_counts['rejected'] + transfer_status_counts['rejected'] + retirement_status_counts['rejected']
    total_submitted = leave_status_counts['submitted'] + transfer_status_counts['submitted'] + retirement_status_counts['submitted']

    # Get recent requests (last 30 days)
    from datetime import timedelta
    thirty_days_ago = timezone.now() - timedelta(days=30)
    recent_leave = leave_requests.filter(created_at__gte=thirty_days_ago)
    recent_transfer = transfer_requests.filter(created_at__gte=thirty_days_ago)
    recent_retirement = retirement_requests.filter(created_at__gte=thirty_days_ago)

    # Calculate monthly statistics
    current_month = timezone.now().month
    current_year = timezone.now().year

    monthly_leave = leave_requests.filter(created_at__month=current_month, created_at__year=current_year)
    monthly_transfer = transfer_requests.filter(created_at__month=current_month, created_at__year=current_year)
    monthly_retirement = retirement_requests.filter(created_at__month=current_month, created_at__year=current_year)

    # Get status filter from request
    status_filter = request.GET.get('status', 'all')
    request_type_filter = request.GET.get('type', 'all')

    # Apply filters
    if status_filter != 'all':
        leave_requests = leave_requests.filter(status=status_filter)
        transfer_requests = transfer_requests.filter(status=status_filter)
        retirement_requests = retirement_requests.filter(status=status_filter)

    if request_type_filter != 'all':
        if request_type_filter == 'leave':
            transfer_requests = TransferRequest.objects.none()
            retirement_requests = RetirementRequest.objects.none()
        elif request_type_filter == 'transfer':
            leave_requests = LeaveRequest.objects.none()
            retirement_requests = RetirementRequest.objects.none()
        elif request_type_filter == 'retirement':
            leave_requests = LeaveRequest.objects.none()
            transfer_requests = TransferRequest.objects.none()

    context = {
        'leave_requests': leave_requests,
        'transfer_requests': transfer_requests,
        'retirement_requests': retirement_requests,
        'leave_status_counts': leave_status_counts,
        'transfer_status_counts': transfer_status_counts,
        'retirement_status_counts': retirement_status_counts,
        'total_requests': total_requests,
        'total_pending': total_pending,
        'total_approved': total_approved,
        'total_rejected': total_rejected,
        'total_submitted': total_submitted,
        'recent_leave': recent_leave,
        'recent_transfer': recent_transfer,
        'recent_retirement': recent_retirement,
        'monthly_leave': monthly_leave,
        'monthly_transfer': monthly_transfer,
        'monthly_retirement': monthly_retirement,
        'status_filter': status_filter,
        'request_type_filter': request_type_filter,
    }
    return render(request, 'portal/admin_request_status.html', context)

# Existing manager views below...

@login_required
def employee_notifications(request):
    """
    Employee notifications page view.
    """
    if request.user.role != 'employee':
        return redirect('portal:home')

    # Get user's notifications
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')

    # Calculate statistics
    total_count = notifications.count()
    unread_count = notifications.filter(is_read=False).count()
    read_count = notifications.filter(is_read=True).count()

    # Get today's notifications
    today = timezone.now().date()
    today_count = notifications.filter(created_at__date=today).count()

    context = {
        'notifications': notifications[:50],  # Show last 50 notifications
        'unread_count': unread_count,
        'read_count': read_count,
        'today_count': today_count,
    }
    return render(request, 'portal/employee_notification.html', context)

@login_required
def manager_notifications(request):
    """
    Manager notifications page view.
    """
    if request.user.role != 'manager':
        return redirect('portal:home')

    # Get user's notifications
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')

    # Calculate statistics
    total_count = notifications.count()
    unread_count = notifications.filter(is_read=False).count()
    read_count = notifications.filter(is_read=True).count()

    # Get today's notifications
    today = timezone.now().date()
    today_count = notifications.filter(created_at__date=today).count()

    # Get pending requests counts for manager-specific stats
    pending_leave_count = LeaveRequest.objects.filter(assigned_manager=request.user, status='pending').count()
    pending_transfer_count = TransferRequest.objects.filter(assigned_manager=request.user, status='pending').count()
    pending_retirement_count = RetirementRequest.objects.filter(assigned_manager=request.user, status='pending').count()

    context = {
        'notifications': notifications[:50],  # Show last 50 notifications
        'unread_count': unread_count,
        'read_count': read_count,
        'today_count': today_count,
        'pending_leave_count': pending_leave_count,
        'pending_transfer_count': pending_transfer_count,
        'pending_retirement_count': pending_retirement_count,
    }
    return render(request, 'portal/manager_notification.html', context)

@login_required
def admin_notifications(request):
    """
    Admin notifications page view.
    """
    if request.user.role != 'admin':
        return redirect('portal:home')

    # Get user's notifications
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')

    # Calculate statistics
    total_count = notifications.count()
    unread_count = notifications.filter(is_read=False).count()
    read_count = notifications.filter(is_read=True).count()

    # Get today's notifications
    today = timezone.now().date()
    today_count = notifications.filter(created_at__date=today).count()

    # Get system-wide statistics for admin
    total_requests_count = (
        LeaveRequest.objects.count() +
        TransferRequest.objects.count() +
        RetirementRequest.objects.count() +
        ResignationRequest.objects.count()
    )

    pending_decisions_count = (
        LeaveRequest.objects.filter(status='pending').count() +
        TransferRequest.objects.filter(status='pending').count() +
        RetirementRequest.objects.filter(status='pending').count() +
        ResignationRequest.objects.filter(status='pending').count()
    )

    active_users_count = User.objects.filter(is_active=True).count()
    new_requests_today = (
        LeaveRequest.objects.filter(created_at__date=today).count() +
        TransferRequest.objects.filter(created_at__date=today).count() +
        RetirementRequest.objects.filter(created_at__date=today).count() +
        ResignationRequest.objects.filter(created_at__date=today).count()
    )

    context = {
        'notifications': notifications[:50],  # Show last 50 notifications
        'unread_count': unread_count,
        'read_count': read_count,
        'today_count': today_count,
        'total_requests_count': total_requests_count,
        'pending_decisions_count': pending_decisions_count,
        'active_users_count': active_users_count,
        'new_requests_today': new_requests_today,
    }
    return render(request, 'portal/admin_notification.html', context)
