from django.urls import path, include
from django.contrib.auth import views as auth_views
from . import views
from . import views_additional

app_name = 'portal'

urlpatterns = [
    path('', views.home, name='home'),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Password reset URLs
    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='portal/password_reset_form.html'), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='portal/password_reset_done.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='portal/password_reset_confirm.html'), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='portal/password_reset_complete.html'), name='password_reset_complete'),

    # Employee URLs
    path('employee/dashboard/', views.employee_dashboard, name='employee_dashboard'),
    path('employee/leave/new/', views.new_leave_request, name='new_leave_request'),
    path('employee/transfer/new/', views.new_transfer_request, name='new_transfer_request'),
    path('employee/retirement/new/', views.new_retirement_request, name='new_retirement_request'),
    path('employee/resignation/new/', views.new_resignation_request, name='new_resignation_request'),
    path('employee/requests/history/', views.employee_request_history, name='employee_request_history'),
    path('employee/requests/download/', views.download_requests_excel, name='download_requests_excel'),
    path('employee/personal_information/', views.personal_information, name='personal_information'),
    path('employee/edit_profile/', views.edit_profile, name='edit_profile'),

    # Manager URLs
    path('manager/dashboard/', views.manager_dashboard, name='manager_dashboard'),
    path('manager/approve/<int:request_id>/', views.manager_approve_request, name='manager_approve_request'),
    path('manager/reject/<int:request_id>/', views.manager_reject_request, name='manager_reject_request'),
    path('manager/submit/<int:request_id>/', views.manager_submit_request, name='manager_submit_request'),
    path('manager/personal_information/', views.personal_information, name='manager_personal_information'),
    path('manager/create/leave/', views.manager_create_leave_request, name='manager_create_leave_request'),
    path('manager/create/transfer/', views.manager_create_transfer_request, name='manager_create_transfer_request'),
    path('manager/create/retirement/', views.manager_create_retirement_request, name='manager_create_retirement_request'),
    path('manager/create/resignation/', views.manager_create_resignation_request, name='manager_create_resignation_request'),
    path('manager/requests/history/', views.manager_request_history, name='manager_request_history'),

    # Admin URLs
    path('portal_admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('portal_admin/approve/<int:request_id>/', views.admin_approve_request, name='admin_approve_request'),
    path('portal_admin/reject/<int:request_id>/', views.admin_reject_request, name='admin_reject_request'),
    path('portal_admin/create/leave/', views.admin_create_leave_request, name='admin_create_leave_request'),
    path('portal_admin/create/transfer/', views.admin_create_transfer_request, name='admin_create_transfer_request'),
    path('portal_admin/create/retirement/', views.admin_create_retirement_request, name='admin_create_retirement_request'),
    path('portal_admin/create/resignation/', views.admin_create_resignation_request, name='admin_create_resignation_request'),
    path('portal_admin/search_users/', views.search_users, name='search_users'),
    path('portal_admin/all_users/', views_additional.admin_all_users, name='admin_all_users'),
    path('portal_admin/create_request/', views_additional.admin_create_request, name='admin_create_request'),

    # Admin Request Management URLs
    path('portal_admin/request_management/', views.admin_request_management, name='admin_request_management'),
    path('portal_admin/request_dashboard/', views.admin_request_dashboard, name='admin_request_dashboard'),
    path('portal_admin/leave_requests/', views.admin_leave_requests, name='admin_leave_requests'),
    path('portal_admin/transfer_requests/', views.admin_transfer_requests, name='admin_transfer_requests'),
    path('portal_admin/retirement_requests/', views.admin_retirement_requests, name='admin_retirement_requests'),
    path('portal_admin/resignation_requests/', views.admin_resignation_requests, name='admin_resignation_requests'),
    path('portal_admin/override/<str:request_type>/<int:request_id>/', views.admin_override_request, name='admin_override_request'),
    path('portal_admin/manager_decisions/', views.admin_view_manager_decisions, name='admin_view_manager_decisions'),

    # Notification URLs
    path('notifications/', views.get_notifications, name='get_notifications'),
    path('notifications/mark_read/<int:notification_id>/', views.mark_notification_read, name='mark_notification_read'),
    path('notifications/mark_all_read/', views.mark_all_notifications_read, name='mark_all_notifications_read'),
    path('notifications/count/', views.get_notification_count, name='get_notification_count'),

    # Notification Pages
    path('employee/notifications/', views.employee_notifications, name='employee_notifications'),
    path('manager/notifications/', views.manager_notifications, name='manager_notifications'),
    path('portal_admin/notifications/', views.admin_notifications, name='admin_notifications'),

    path('', include('portal.urls_additional')),
]
