from django import forms
from django.contrib.auth.forms import UserCreationForm as BaseUserCreationForm
from .models import LeaveRequest, TransferRequest, RetirementRequest, ResignationRequest, User

class UserCreationForm(BaseUserCreationForm):
    """Custom user creation form for the portal User model"""
    first_name = forms.CharField(max_length=30, required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    last_name = forms.CharField(max_length=150, required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    designation = forms.CharField(max_length=100, required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    department = forms.CharField(max_length=100, required=True, widget=forms.TextInput(attrs={'class': 'form-control'}))
    pl_no = forms.CharField(max_length=20, required=True, label='Personal Number', widget=forms.TextInput(attrs={'class': 'form-control'}))
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}))

    class Meta:
        model = User
        fields = ("username", "first_name", "last_name", "designation", "department", "pl_no", "password1", "password2")

    def save(self, commit=True):
        user = super().save(commit=False)
        user.first_name = self.cleaned_data["first_name"]
        user.last_name = self.cleaned_data["last_name"]
        user.designation = self.cleaned_data["designation"]
        user.department = self.cleaned_data["department"]
        user.pl_no = self.cleaned_data["pl_no"]
        if commit:
            user.save()
        return user

class AdminLeaveRequestForm(forms.ModelForm):
    LEAVE_TYPE_CHOICES = [
         ('SL', 'Sick Leave'),
        ('LFP', 'Leave for Personal Reasons'),
        ('CPL', 'Compensontry Leave'),
        ('CL', 'Casual leave'),
        ('Other', 'Other'),
    ]
    DAY_TYPE_CHOICES = [
        ('Half', 'Half'),
        ('Full', 'Full'),
    ]
    user = forms.ModelChoiceField(queryset=User.objects.all(), label='User', widget=forms.Select(attrs={'class': 'form-control'}))
    pl_no = forms.CharField(max_length=20, required=False, label='PL No', widget=forms.TextInput(attrs={ 'class': 'form-control'}))
    leave_type = forms.ChoiceField(choices=LEAVE_TYPE_CHOICES, required=False, label='Leave Type', widget=forms.Select(attrs={'class': 'form-control'}))
    start_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    end_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    day_type = forms.ChoiceField(choices=DAY_TYPE_CHOICES, required=False, label='Day Type', widget=forms.Select(attrs={'class': 'form-control'}))
    reason = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False)
    apply_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}), label='Apply Date')

    class Meta:
        model = LeaveRequest
        fields = ['user', 'pl_no', 'leave_type', 'start_date', 'end_date', 'day_type', 'reason', 'apply_date']

class AdminTransferRequestForm(forms.ModelForm):
    user = forms.ModelChoiceField(queryset=User.objects.all(), label='User', widget=forms.Select(attrs={'class': 'form-control'}))
    pl_no = forms.CharField(max_length=20, required=False, label='Pl_NO', widget=forms.TextInput(attrs={ 'class': 'form-control'}))
    current_department = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    requested_department = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    reason = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False)

    class Meta:
        model = TransferRequest
        fields = ['user', 'pl_no', 'current_department', 'requested_department', 'reason']

class AdminRetirementRequestForm(forms.ModelForm):
    user = forms.ModelChoiceField(queryset=User.objects.all(), label='User', widget=forms.Select(attrs={'class': 'form-control'}))
    pl_no = forms.CharField(max_length=20, required=False, label='Pl_NO', widget=forms.TextInput(attrs={ 'class': 'form-control'}))
    retirement_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    reason = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False)

    class Meta:
        model = RetirementRequest
        fields = ['user', 'pl_no', 'retirement_date', 'reason']

class AdminResignationRequestForm(forms.ModelForm):
    user = forms.ModelChoiceField(queryset=User.objects.all(), label='User', widget=forms.Select(attrs={'class': 'form-control'}))
    pl_no = forms.CharField(max_length=20, required=False, label='Pl_NO', widget=forms.TextInput(attrs={ 'class': 'form-control'}))
    resignation_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    reason = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False)

    class Meta:
        model = ResignationRequest
        fields = ['user', 'pl_no', 'resignation_date', 'reason']

class LeaveRequestForm(forms.ModelForm):
    LEAVE_TYPE_CHOICES = [
        ('SL', 'Sick Leave'),
        ('LFP', 'Leave for Personal Reasons'),
        ('CPL', 'Compensontry Leave'),
        ('CL', 'Casual leave'),
        ('Other', 'Other'),
    ]
    DAY_TYPE_CHOICES = [
        ('Half', 'Half'),
        ('Full', 'Full'),
    ]
    pl_no = forms.CharField(
        max_length=20,
        required=False,
        label='PL No',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'list': 'pl_no_suggestions',
            'placeholder': 'Enter your PL No '
        })
    )
    leave_type = forms.ChoiceField(choices=LEAVE_TYPE_CHOICES, required=False, label='Leave Type', widget=forms.Select(attrs={'class': 'form-control'}))
    start_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    end_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    day_type = forms.ChoiceField(choices=DAY_TYPE_CHOICES, required=False, label='Day Type', widget=forms.Select(attrs={'class': 'form-control'}))
    reason = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False)
    apply_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}), label='Apply Date')
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user:
            # Auto-populate PL No from user profile if not already set
            if not self.instance.pk and user.pl_no:
                self.fields['pl_no'].initial = user.pl_no

    class Meta:
        model = LeaveRequest
        fields = ['pl_no','leave_type', 'start_date', 'end_date', 'reason']

class TransferRequestForm(forms.ModelForm):
    pl_no = forms.CharField(
        max_length=20,
        required=False,
        label='PL No',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'list': 'pl_no_suggestions',
            'placeholder': 'Enter your PL No'
        })
    )
    current_department = forms.CharField(max_length=100, widget=forms.TextInput(attrs={ 'class': 'form-control'}))
    requested_department = forms.CharField(max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    reason = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False)

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user:
            self.fields['current_department'].initial = user.department
            # Auto-populate PL No from user profile if not already set
            if not self.instance.pk and user.pl_no:
                self.fields['pl_no'].initial = user.pl_no

    class Meta:
        model = TransferRequest
        fields = ['pl_no','current_department', 'requested_department', 'reason']

class RetirementRequestForm(forms.ModelForm):
    pl_no = forms.CharField(
        max_length=20,
        required=False,
        label='PL No',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'list': 'pl_no_suggestions',
            'placeholder': 'Enter your PL No'
        })
    )
    retirement_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    reason = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False)

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user:
            # Auto-populate PL No from user profile if not already set
            if not self.instance.pk and user.pl_no:
                self.fields['pl_no'].initial = user.pl_no

    class Meta:
        model = RetirementRequest
        fields = ['pl_no','retirement_date', 'reason']

class ResignationRequestForm(forms.ModelForm):
    pl_no = forms.CharField(
        max_length=20,
        required=False,
        label='PL No',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'list': 'pl_no_suggestions',
            'placeholder': 'Enter your PL No'
        })
    )
    resignation_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    reason = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 4}), required=False)

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user:
            # Auto-populate PL No from user profile if not already set
            if not self.instance.pk and user.pl_no:
                self.fields['pl_no'].initial = user.pl_no

    class Meta:
        model = ResignationRequest
        fields = ['pl_no','resignation_date', 'reason']

class UserProfileForm(forms.ModelForm):
    """Form for users to edit their profile including PL No"""
    pl_no = forms.CharField(
        max_length=20,
        required=False,
        label='PL No',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'list': 'pl_no_suggestions',
            'placeholder': 'Enter your PL No'
        })
    )
    designation = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    department = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={'class': 'form-control'}))
    date_of_joining = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))
    retirement_age = forms.IntegerField(required=False, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    total_leaves_per_year = forms.IntegerField(required=False, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    total_leaves_per_month = forms.IntegerField(required=False, widget=forms.NumberInput(attrs={'class': 'form-control'}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add datalist suggestions for PL No
        self.fields['pl_no'].widget.attrs['list'] = 'pl_no_suggestions'

    class Meta:
        model = User
        fields = ['pl_no', 'designation', 'department', 'date_of_joining', 'retirement_age', 'total_leaves_per_year', 'total_leaves_per_month']

    def clean_pl_no(self):
        pl_no = self.cleaned_data.get('pl_no')
        if pl_no:
            # Check if PL No is already taken by another user
            existing_user = User.objects.filter(pl_no=pl_no).exclude(pk=self.instance.pk).first()
            if existing_user:
                raise forms.ValidationError(f"PL No '{pl_no}' is already assigned to another user.")
        return pl_no
