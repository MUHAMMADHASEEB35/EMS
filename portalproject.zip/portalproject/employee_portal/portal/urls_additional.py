from django.urls import path
from . import views_additional

urlpatterns = [
    path('profile/', views_additional.profile_view, name='profile'),
    path('edit-profile/', views_additional.edit_profile_view, name='edit_profile'),
    path('restore-defaults/', views_additional.restore_defaults_view, name='restore_defaults'),
    path('admin_all_users/', views_additional.admin_all_users, name='admin_all_users'),
    path('admin_create_request/', views_additional.admin_create_request, name='admin_create_request'),
    path('manager_task_assign/', views_additional.manager_task_assign, name='manager_task_assign'),
    path('manager_task_overview/', views_additional.manager_task_overview, name='manager_task_overview'),
    path('admin_history/', views_additional.admin_history, name='admin_history'),
     path('change-password/', views_additional.CustomPasswordChangeView.as_view(), name='change_password'),
]
