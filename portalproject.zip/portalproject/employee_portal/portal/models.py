from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models

class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(username, email, password, **extra_fields)

class User(AbstractUser):
    ROLE_CHOICES = (
        ('employee', 'Employee'),
        ('manager', 'Manager'),
        ('admin', 'Admin'),
    )
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    pl_no = models.CharField(max_length=20, unique=True, blank=True, null=True)
    designation = models.CharField(max_length=100, blank=True, null=True)
    department = models.CharField(max_length=100, blank=True, null=True)
    date_of_joining = models.DateField(blank=True, null=True)
    retirement_age = models.IntegerField(default=60, blank=True, null=True)
    total_leaves_per_year = models.IntegerField(default=30, blank=True, null=True)
    total_leaves_per_month = models.IntegerField(default=2, blank=True, null=True)

    objects = UserManager()

    def __str__(self):
        return f"{self.username} ({self.role})"

    def save(self, *args, **kwargs):
        # Auto-generate PL No from username if not provided
        if not self.pl_no and self.username:
            self.pl_no = self.generate_pl_no()
        super().save(*args, **kwargs)

    def generate_pl_no(self):
        """
        Generate PL No from username.
        Format: EMP + first 3 chars of username + random 4 digits
        Example: EMPJOH1234
        """
        import random
        if self.username:
            username_part = self.username[:3].upper()
            random_digits = str(random.randint(1000, 9999))
            return f"EMP{username_part}{random_digits}"
        return ""

    def get_pl_no_display(self):
        """Get PL No for display purposes"""
        return self.pl_no if self.pl_no else "Not assigned"

class LeaveRequest(models.Model):
    LEAVE_TYPE_CHOICES = (
       ('SL', 'Sick Leave'),
        ('LFP', 'Leave for Personal Reasons'),
        ('CPL', 'Compensontry Leave'),
        ('CL', 'Casual leave'),
        ('Other', 'Other'),
    )
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    ADMIN_OVERRIDE_STATUS_CHOICES = (
        ('none', 'No Override'),
        ('overridden_approved', 'Admin Overrode to Approved'),
        ('overridden_rejected', 'Admin Overrode to Rejected'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='leave_requests')
    pl_no = models.CharField(max_length=20, unique=True, blank=True, null=True)
    assigned_manager = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_leave_requests', limit_choices_to={'role': 'manager'})
    leave_type = models.CharField(max_length=10, choices=LEAVE_TYPE_CHOICES, default='Other')
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    # Admin override fields
    admin_override_status = models.CharField(max_length=20, choices=ADMIN_OVERRIDE_STATUS_CHOICES, default='none')
    admin_override_reason = models.TextField(blank=True, null=True)
    admin_override_timestamp = models.DateTimeField(blank=True, null=True)
    admin_override_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='admin_overridden_leave_requests', limit_choices_to={'role': 'admin'})

    @property
    def request_type(self):
        return self._request_type if hasattr(self, '_request_type') else 'leave'

    @request_type.setter
    def request_type(self, value):
        self._request_type = value

    def __str__(self):
        return f"LeaveRequest({self.user.username}, {self.status})"

class TransferRequest(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    ADMIN_OVERRIDE_STATUS_CHOICES = (
        ('none', 'No Override'),
        ('overridden_approved', 'Admin Overrode to Approved'),
        ('overridden_rejected', 'Admin Overrode to Rejected'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transfer_requests')
    pl_no = models.CharField(max_length=20, unique=True, blank=True, null=True)
    assigned_manager = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_transfer_requests', limit_choices_to={'role': 'manager'})
    current_department = models.CharField(max_length=100)
    requested_department = models.CharField(max_length=100)
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    # Admin override fields
    admin_override_status = models.CharField(max_length=20, choices=ADMIN_OVERRIDE_STATUS_CHOICES, default='none')
    admin_override_reason = models.TextField(blank=True, null=True)
    admin_override_timestamp = models.DateTimeField(blank=True, null=True)
    admin_override_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='admin_overridden_transfer_requests', limit_choices_to={'role': 'admin'})

    @property
    def request_type(self):
        return self._request_type if hasattr(self, '_request_type') else 'transfer'

    @request_type.setter
    def request_type(self, value):
        self._request_type = value

    def __str__(self):
        return f"TransferRequest({self.user.username}, {self.status})"

class RetirementRequest(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    ADMIN_OVERRIDE_STATUS_CHOICES = (
        ('none', 'No Override'),
        ('overridden_approved', 'Admin Overrode to Approved'),
        ('overridden_rejected', 'Admin Overrode to Rejected'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='retirement_requests')
    pl_no = models.CharField(max_length=20, unique=True, blank=True, null=True)
    assigned_manager = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_retirement_requests', limit_choices_to={'role': 'manager'})
    retirement_date = models.DateField()
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    # Admin override fields
    admin_override_status = models.CharField(max_length=20, choices=ADMIN_OVERRIDE_STATUS_CHOICES, default='none')
    admin_override_reason = models.TextField(blank=True, null=True)
    admin_override_timestamp = models.DateTimeField(blank=True, null=True)
    admin_override_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='admin_overridden_retirement_requests', limit_choices_to={'role': 'admin'})

    @property
    def request_type(self):
        return self._request_type if hasattr(self, '_request_type') else 'retirement'

    @request_type.setter
    def request_type(self, value):
        self._request_type = value

    def __str__(self):
        return f"RetirementRequest({self.user.username}, {self.status})"

class ResignationRequest(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    )
    ADMIN_OVERRIDE_STATUS_CHOICES = (
        ('none', 'No Override'),
        ('overridden_approved', 'Admin Overrode to Approved'),
        ('overridden_rejected', 'Admin Overrode to Rejected'),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='resignation_requests')
    pl_no = models.CharField(max_length=20, unique=True, blank=True, null=True)
    assigned_manager = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_resignation_requests', limit_choices_to={'role': 'manager'})
    resignation_date = models.DateField()
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    # Admin override fields
    admin_override_status = models.CharField(max_length=20, choices=ADMIN_OVERRIDE_STATUS_CHOICES, default='none')
    admin_override_reason = models.TextField(blank=True, null=True)
    admin_override_timestamp = models.DateTimeField(blank=True, null=True)
    admin_override_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='admin_overridden_resignation_requests', limit_choices_to={'role': 'admin'})

    @property
    def request_type(self):
        return self._request_type if hasattr(self, '_request_type') else 'resignation'

    @request_type.setter
    def request_type(self, value):
        self._request_type = value

    def __str__(self):
        return f"ResignationRequest({self.user.username}, {self.status})"

class Notification(models.Model):
    NOTIFICATION_TYPE_CHOICES = (
        ('request_submitted', 'Request Submitted'),
        ('request_approved', 'Request Approved'),
        ('request_rejected', 'Request Rejected'),
        ('service_complete', 'Service Complete'),
        ('retirement_due', 'Retirement Due'),
        ('info', 'Information'),
    )

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPE_CHOICES)
    title = models.CharField(max_length=200)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    related_object_type = models.CharField(max_length=50, blank=True, null=True)  # e.g., 'leave', 'transfer', 'retirement'
    related_object_id = models.IntegerField(blank=True, null=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Notification({self.user.username}, {self.notification_type}, {self.title})"
