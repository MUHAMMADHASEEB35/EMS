from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model

User = get_user_model()

class TestPortal(TestCase):
    def setUp(self):
        self.client = Client()
        self.employee_user = User.objects.create_user(
            username='employee1',
            email='employee1@example.com',
            password='testpass123',
            role='employee'
        )
        self.manager_user = User.objects.create_user(
            username='manager1',
            email='manager1@example.com',
            password='testpass123',
            role='manager'
        )
        self.admin_user = User.objects.create_user(
            username='admin1',
            email='admin1@example.com',
            password='testpass123',
            role='admin'
        )

    def test_sidebar_links_employee(self):
        self.client.login(username='employee1', password='testpass123')
        response = self.client.get(reverse('portal:employee_dashboard'))
        self.assertContains(response, 'New Leave Request')
        self.assertContains(response, 'New Transfer Request')
        self.assertContains(response, 'New Retirement Request')
        self.assertContains(response, 'Request History')

    def test_sidebar_links_manager(self):
        self.client.login(username='manager1', password='testpass123')
        response = self.client.get(reverse('portal:manager_dashboard'))
        self.assertContains(response, 'Manager Dashboard')

    def test_sidebar_links_admin(self):
        self.client.login(username='admin1', password='testpass123')
        response = self.client.get(reverse('portal:admin_dashboard'))
        self.assertContains(response, 'Admin Dashboard')

    def test_signup_redirects_based_on_role(self):
        response = self.client.post(reverse('portal:signup'), {
            'username': 'newemployee',
            'email': 'newemployee@example.com',
            'password1': 'newpass123',
            'password2': 'newpass123',
            'role': 'employee',
        })
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse('portal:employee_dashboard'), response.url)

    def test_leave_request_form_access(self):
        self.client.login(username='employee1', password='testpass123')
        response = self.client.get(reverse('portal:new_leave_request'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Submit Leave Request')

    def test_request_history_access(self):
        self.client.login(username='employee1', password='testpass123')
        response = self.client.get(reverse('portal:employee_request_history'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Request History')
