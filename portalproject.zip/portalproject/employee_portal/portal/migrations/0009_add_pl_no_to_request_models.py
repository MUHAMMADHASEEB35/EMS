# Generated manually to fix ProgrammingError: column portal_leaverequest.pl_no does not exist

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('portal', '0008_leaverequest_leave_type'),
    ]

    operations = [
        migrations.AddField(
            model_name='leaverequest',
            name='pl_no',
            field=models.CharField(max_length=20, unique=True, blank=True, null=True),
        ),
        migrations.AddField(
            model_name='transferrequest',
            name='pl_no',
            field=models.CharField(max_length=20, unique=True, blank=True, null=True),
        ),
        migrations.AddField(
            model_name='retirementrequest',
            name='pl_no',
            field=models.CharField(max_length=20, unique=True, blank=True, null=True),
        ),
    ]
