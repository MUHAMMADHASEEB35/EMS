from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .forms import AdminLeaveRequestForm, AdminTransferRequestForm, AdminRetirementRequestForm, AdminResignationRequestForm
from .models import User

from django.contrib.auth.views import PasswordChangeView
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin

@login_required
def track_request_view(request):
    # Placeholder view for tracking requests
    return render(request, 'portal/track_request.html')

@login_required
def admin_all_users(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        new_role = request.POST.get('new_role')
        new_designation = request.POST.get('new_designation')
        try:
            user = User.objects.get(id=user_id)
            if new_role:
                user.role = new_role
            if new_designation is not None:
                user.designation = new_designation
            user.save()
            messages.success(request, f'Updated user {user.username}.')
        except User.DoesNotExist:
            messages.error(request, 'User not found.')
        return redirect('portal:admin_all_users')

    search_query = request.GET.get('search', '')
    users = User.objects.all()
    if search_query:
        users = users.filter(username__icontains=search_query) | users.filter(pl_no__icontains=search_query) | users.filter(designation__icontains=search_query) | users.filter(department__icontains=search_query)

    # Sort: employees first, then managers, then admins
    users = sorted(users, key=lambda u: {'employee': 0, 'manager': 1, 'admin': 2}.get(u.role, 3))

    context = {
        'users': users,
        'search_query': search_query,
    }
    return render(request, 'portal/admin_all_users.html', context)

class CustomPasswordChangeView(LoginRequiredMixin, SuccessMessageMixin, PasswordChangeView):
    template_name = 'portal/change_password.html'
    success_url = reverse_lazy('portal:personal_information')
    success_message = "Your password was changed successfully."

@login_required
def admin_create_request(request):
    if request.method == 'POST':
        form_type = request.POST.get('form_type')
        if form_type == 'leave':
            form = AdminLeaveRequestForm(request.POST)
            if form.is_valid():
                leave_request = form.save(commit=False)
                leave_request.status = 'approved'  # Auto-approved
                leave_request.save()
                messages.success(request, 'Leave request created and approved.')
                return redirect('portal:admin_dashboard')
        elif form_type == 'transfer':
            form = AdminTransferRequestForm(request.POST)
            if form.is_valid():
                transfer_request = form.save(commit=False)
                transfer_request.status = 'approved'  # Auto-approved
                transfer_request.save()
                messages.success(request, 'Transfer request created and approved.')
                return redirect('portal:admin_dashboard')
        elif form_type == 'retirement':
            form = AdminRetirementRequestForm(request.POST)
            if form.is_valid():
                retirement_request = form.save(commit=False)
                retirement_request.status = 'approved'  # Auto-approved
                retirement_request.save()
                messages.success(request, 'Retirement request created and approved.')
                return redirect('portal:admin_dashboard')
        elif form_type == 'resignation':
            form = AdminResignationRequestForm(request.POST)
            if form.is_valid():
                resignation_request = form.save(commit=False)
                resignation_request.status = 'approved'  # Auto-approved
                resignation_request.save()
                messages.success(request, 'Resignation request created and approved.')
                return redirect('portal:admin_dashboard')
        else:
            messages.error(request, 'Invalid form type.')
            return redirect('portal:admin_create_request')

    leave_form = AdminLeaveRequestForm()
    transfer_form = AdminTransferRequestForm()
    retirement_form = AdminRetirementRequestForm()
    resignation_form = AdminResignationRequestForm()
    context = {
        'leave_form': leave_form,
        'transfer_form': transfer_form,
        'retirement_form': retirement_form,
        'resignation_form': resignation_form,
    }
    return render(request, 'portal/admin_create_request.html', context)

@login_required
def profile_view(request):
    # Stub implementation - render a simple profile page
    return render(request, 'portal/profile.html', {})

@login_required
def edit_profile_view(request):
    # Stub implementation - render a simple edit profile page
    return render(request, 'portal/edit_profile.html', {})

@login_required
def restore_defaults_view(request):
    # Stub implementation - render a simple restore defaults page
    return render(request, 'portal/restore_defaults.html', {})

from django.db.models import Q
from .models import LeaveRequest, TransferRequest, RetirementRequest

@login_required
def manager_task_assign(request):
    managers = list(User.objects.filter(role='manager'))
    admin_user = request.user if request.user.role == 'admin' else None

    # Get all employees
    employees = User.objects.filter(role='employee')

    # Calculate total daily orders from each employee (all request types)
    from django.db.models import Count
    leave_orders = LeaveRequest.objects.values('user').annotate(total_orders=Count('id'))
    transfer_orders = TransferRequest.objects.values('user').annotate(total_orders=Count('id'))
    retirement_orders = RetirementRequest.objects.values('user').annotate(total_orders=Count('id'))

    # Create list of employees with their total orders
    employee_data = []
    for employee in employees:
        leave_count = next((item['total_orders'] for item in leave_orders if item['user'] == employee.id), 0)
        transfer_count = next((item['total_orders'] for item in transfer_orders if item['user'] == employee.id), 0)
        retirement_count = next((item['total_orders'] for item in retirement_orders if item['user'] == employee.id), 0)
        total_orders = leave_count + transfer_count + retirement_count
        employee_data.append({'employee': employee, 'total_orders': total_orders})

    # Get unassigned requests (pending or submitted) for all request types
    leave_requests = list(LeaveRequest.objects.filter(Q(status__in=['pending', 'submitted']), assigned_manager__isnull=True))
    transfer_requests = list(TransferRequest.objects.filter(Q(status__in=['pending', 'submitted']), assigned_manager__isnull=True))
    retirement_requests = list(RetirementRequest.objects.filter(Q(status__in=['pending', 'submitted'])))

    # Auto-assign tasks equally among managers if GET request
    if request.method == 'GET' and managers:
        # Only assign tasks that currently have no assigned manager
        unassigned_leave_requests = [req for req in leave_requests if req.assigned_manager is None]
        unassigned_transfer_requests = [req for req in transfer_requests if req.assigned_manager is None]
        unassigned_retirement_requests = [req for req in retirement_requests if req.assigned_manager is None]

        all_unassigned_requests = unassigned_leave_requests + unassigned_transfer_requests + unassigned_retirement_requests

        for idx, req in enumerate(all_unassigned_requests):
            assigned_manager = managers[idx % len(managers)]
            req.assigned_manager = assigned_manager
            req.save()

        # Refresh lists after assignment
        leave_requests = LeaveRequest.objects.filter(Q(status__in=['pending', 'submitted']), assigned_manager__isnull=True)
        transfer_requests = TransferRequest.objects.filter(Q(status__in=['pending', 'submitted']), assigned_manager__isnull=True)
        retirement_requests = RetirementRequest.objects.filter(Q(status__in=['pending', 'submitted']))

    # Create list of managers with their daily orders assigned
    manager_data = []
    for manager in managers:
        assigned_leave = LeaveRequest.objects.filter(assigned_manager=manager)
        assigned_transfer = TransferRequest.objects.filter(assigned_manager=manager)
        assigned_retirement = RetirementRequest.objects.filter(assigned_manager=manager)
        assigned_requests = list(assigned_leave) + list(assigned_transfer) + list(assigned_retirement)
        # Add request_type to each request
        for req in assigned_requests:
            req.request_type = req.__class__.__name__
        daily_orders = len(assigned_requests)
        manager_data.append({'manager': manager, 'daily_orders': daily_orders, 'assigned_requests': assigned_requests})

    if request.method == 'POST':
        # Check if this is an AJAX request
        is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

        # Assign manager to requests based on POST data (admin can override)
        if admin_user:
            for req_type, model, requests in [('leave', LeaveRequest, leave_requests),
                                              ('transfer', TransferRequest, transfer_requests),
                                              ('retirement', RetirementRequest, retirement_requests)]:
                for req in requests:
                    manager_id = request.POST.get(f'{req_type}_manager_{req.id}')
                    if manager_id:
                        try:
                            manager = User.objects.get(id=manager_id, role='manager')
                            req.assigned_manager = manager
                            req.save()
                        except User.DoesNotExist:
                            pass

        # Recalculate manager data after assignments to ensure accurate counts
        manager_data = []
        for manager in managers:
            assigned_leave = LeaveRequest.objects.filter(assigned_manager=manager)
            assigned_transfer = TransferRequest.objects.filter(assigned_manager=manager)
            assigned_retirement = RetirementRequest.objects.filter(assigned_manager=manager)
            assigned_requests = list(assigned_leave) + list(assigned_transfer) + list(assigned_retirement)
            # Add request_type to each request
            for req in assigned_requests:
                req.request_type = req.__class__.__name__
            daily_orders = len(assigned_requests)
            manager_data.append({'manager': manager, 'daily_orders': daily_orders, 'assigned_requests': assigned_requests})

        if is_ajax:
            # Return JSON response for AJAX requests with updated data
            return JsonResponse({
                'success': True,
                'message': 'Assignments updated successfully',
                'updated_data': {
                    'manager_data': [
                        {
                            'manager': {'id': item['manager'].id, 'username': item['manager'].username},
                            'daily_orders': item['daily_orders']
                        } for item in manager_data
                    ]
                }
            })
        else:
            # Return regular redirect for normal form submissions
            return redirect('portal:manager_task_assign')

    request_types = [('Leave', leave_requests), ('Transfer', transfer_requests), ('Retirement', retirement_requests)]

    context = {
        'manager_data': manager_data,
        'employee_data': employee_data,
        'leave_requests': leave_requests,
        'transfer_requests': transfer_requests,
        'retirement_requests': retirement_requests,
        'managers': managers,
        'admin_user': admin_user,
        'request_types': request_types,
    }
    return render(request, 'portal/manager_task_assign.html', context)

@login_required
def manager_task_overview(request):
    managers = User.objects.filter(role='manager')
    # For each manager, get counts of assigned requests by type and status
    manager_data = []
    for manager in managers:
        leave_count = LeaveRequest.objects.filter(assigned_manager=manager).count()
        transfer_count = TransferRequest.objects.filter(assigned_manager=manager).count()
        retirement_count = RetirementRequest.objects.filter(assigned_manager=manager).count()
        manager_data.append({
            'manager': manager,
            'leave_count': leave_count,
            'transfer_count': transfer_count,
            'retirement_count': retirement_count,
        })
    context = {
        'manager_data': manager_data,
    }
    return render(request, 'portal/manager_task_overview.html', context)

@login_required
def admin_history(request):
    from django.core.paginator import Paginator
    from django.db.models import Q
    import csv
    from django.http import HttpResponse

    # Get search and sort parameters
    search_query = request.GET.get('search', '')
    sort_by = request.GET.get('sort', 'newest')  # newest or oldest
    per_page = int(request.GET.get('per_page', 10))
    download = request.GET.get('download', '')

    # Combine all requests into a list with type
    all_requests = []

    leave_requests = LeaveRequest.objects.all()
    for req in leave_requests:
        req.request_type = 'Leave'
        all_requests.append(req)

    transfer_requests = TransferRequest.objects.all()
    for req in transfer_requests:
        req.request_type = 'Transfer'
        all_requests.append(req)

    retirement_requests = RetirementRequest.objects.all()
    for req in retirement_requests:
        req.request_type = 'Retirement'
        all_requests.append(req)

    # Apply search filter
    if search_query:
        all_requests = [req for req in all_requests if search_query.lower() in req.user.username.lower() or search_query.lower() in req.request_type.lower()]

    # Apply sorting
    if sort_by == 'oldest':
        all_requests.sort(key=lambda x: x.created_at)
    else:  # newest
        all_requests.sort(key=lambda x: x.created_at, reverse=True)

    # Handle XLS download
    if download == 'xls':
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="admin_history.csv"'
        writer = csv.writer(response)
        writer.writerow(['User', 'Request Type', 'Status', 'Created At'])
        for req in all_requests:
            writer.writerow([req.user.username, req.request_type, req.status, req.created_at.strftime('%Y-%m-%d %H:%M:%S')])
        return response

    # Pagination
    paginator = Paginator(all_requests, per_page)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'sort_by': sort_by,
        'per_page': per_page,
    }
    return render(request, 'portal/admin_history.html', context)
