#!/usr/bin/env python
import os
import sys
import django

# Add the project directory to the Python path
sys.path.append('g:/portalproject')
os.chdir('g:/portalproject')

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'employee_portal.employee_portal.settings')
django.setup()

from employee_portal.portal.models import User, Notification
from django.contrib.auth import get_user_model

User = get_user_model()

try:
    # Get the first user (assuming there's at least one user in the system)
    user = User.objects.first()
    if user:
        # Create a test notification
        notification = Notification.objects.create(
            user=user,
            notification_type='info',
            title='Test Notification',
            message='This is a test notification to verify the system is working.',
            is_read=False
        )
        print(f'✅ Created test notification for user: {user.username}')
        print(f'📋 Notification ID: {notification.id}')
        print(f'🔔 Total notifications for user: {Notification.objects.filter(user=user, is_read=False).count()}')

        # Test the notification view
        from django.test import Client
        from django.contrib.auth import get_user_model

        client = Client()
        client.login(username=user.username, password='password')  # Adjust password as needed

        response = client.get('/portal/notifications/')
        print(f'🌐 Notification view response status: {response.status_code}')

        if response.status_code == 200:
            data = response.json()
            print(f'📊 Notifications returned: {len(data.get("notifications", []))}')
            print('✅ Notification system is working correctly!')
        else:
            print(f'❌ Error in notification view: {response.content}')

    else:
        print('❌ No users found in the system')

except Exception as e:
    print(f'❌ Error: {e}')
    import traceback
    traceback.print_exc()
