#!/usr/bin/env python
import os
import sys
import django

# Add the project directory to the Python path
sys.path.append('g:/portalproject/employee_portal')
os.chdir('g:/portalproject/employee_portal')

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'employee_portal.settings')
django.setup()

from portal.models import User, Notification
from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import datetime, timedelta

User = get_user_model()

def create_test_notifications():
    """Create test notifications for the current user"""
    try:
        print("🔍 Creating test notifications...")

        # Get the first user
        user = User.objects.first()
        if not user:
            print("❌ No users found in the system")
            return False

        print(f"👤 Creating notifications for user: {user.username}")

        # Create multiple test notifications
        notifications_data = [
            {
                'notification_type': 'info',
                'title': 'Welcome to the Portal!',
                'message': 'Welcome to the Employee Portal. You can manage your leave requests, transfers, and retirement here.',
            },
            {
                'notification_type': 'request_submitted',
                'title': 'Leave Request Submitted',
                'message': 'Your leave request for next week has been submitted and is pending approval.',
            },
            {
                'notification_type': 'request_approved',
                'title': 'Transfer Request Approved',
                'message': 'Congratulations! Your transfer request to the IT department has been approved.',
            },
            {
                'notification_type': 'service_complete',
                'title': 'Profile Updated',
                'message': 'Your profile information has been successfully updated.',
            },
        ]

        created_count = 0
        for i, data in enumerate(notifications_data):
            # Create notification with different timestamps
            created_at = timezone.now() - timedelta(hours=i)

            notification = Notification.objects.create(
                user=user,
                notification_type=data['notification_type'],
                title=data['title'],
                message=data['message'],
                is_read=False,
                created_at=created_at
            )
            created_count += 1
            print(f"✅ Created: {data['title']}")

        print(f"🎉 Successfully created {created_count} test notifications!")
        print(f"🔔 Total unread notifications for {user.username}: {Notification.objects.filter(user=user, is_read=False).count()}")

        return True

    except Exception as e:
        print(f"❌ Error creating notifications: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    create_test_notifications()
