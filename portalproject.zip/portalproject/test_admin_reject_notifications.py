#!/usr/bin/env python
"""
Test script to verify that admin reject functionality sends notifications to managers.
This test focuses specifically on the admin_reject_request function.
"""
import os
import sys
import django

# Add the project directory to the Python path
sys.path.append('g:/portalproject')
os.chdir('g:/portalproject')

# Set up Django with minimal configuration for testing
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'employee_portal.employee_portal.settings')

# Override database settings for testing
from django.conf import settings
if not settings.configured:
    settings.configure(
        DEBUG=True,
        DATABASES={
            'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': ':memory:',
            }
        },
        INSTALLED_APPS=[
            'django.contrib.auth',
            'django.contrib.contenttypes',
            'portal',
        ],
        SECRET_KEY='test-secret-key',
        USE_TZ=True,
        AUTH_USER_MODEL='portal.User',
    )

django.setup()

from django.contrib.auth import get_user_model
from employee_portal.portal.models import User, Notification, LeaveRequest
from employee_portal.portal.views import admin_reject_request
from django.test import RequestFactory
from django.contrib.messages.storage.fallback import FallbackStorage

User = get_user_model()

def test_admin_reject_notifications():
    """Test that admin reject sends notifications to managers."""
    print("🧪 Starting admin reject notification test...")

    try:
        # Create test users
        admin_user = User.objects.create_user(
            username='admin_test',
            password='admin123',
            role='admin',
            email='admin@test.com'
        )

        manager_user = User.objects.create_user(
            username='manager_test',
            password='manager123',
            role='manager',
            email='manager@test.com'
        )

        employee_user = User.objects.create_user(
            username='employee_test',
            password='employee123',
            role='employee',
            email='employee@test.com'
        )

        print(f"✅ Created test users: admin={admin_user.username}, manager={manager_user.username}, employee={employee_user.username}")

        # Create a test leave request
        leave_request = LeaveRequest.objects.create(
            user=employee_user,
            leave_type='Short Leave',
            start_date='2024-01-15',
            end_date='2024-01-15',
            reason='Test leave request',
            status='pending'
        )

        print(f"✅ Created test leave request ID: {leave_request.id}")

        # Create a mock request object
        factory = RequestFactory()
        request = factory.post(f'/admin/reject/{leave_request.id}/')
        request.user = admin_user

        # Add messages framework to request
        setattr(request, 'session', {})
        messages = FallbackStorage(request)
        setattr(request, '_messages', messages)

        # Call the admin_reject_request function
        print("🔄 Calling admin_reject_request function...")
        response = admin_reject_request(request, leave_request.id)

        # Check if notifications were created
        employee_notifications = Notification.objects.filter(user=employee_user)
        manager_notifications = Notification.objects.filter(user=manager_user)

        print(f"📊 Employee notifications count: {employee_notifications.count()}")
        print(f"📊 Manager notifications count: {manager_notifications.count()}")

        # Verify employee notification
        employee_notification = employee_notifications.first()
        if employee_notification:
            print(f"✅ Employee notification: {employee_notification.title}")
            print(f"   Message: {employee_notification.message}")
            assert 'rejected' in employee_notification.message.lower()
            assert employee_user.username in employee_notification.message
        else:
            print("❌ No employee notification found!")
            return False

        # Verify manager notification
        manager_notification = manager_notifications.first()
        if manager_notification:
            print(f"✅ Manager notification: {manager_notification.title}")
            print(f"   Message: {manager_notification.message}")
            assert 'rejected' in manager_notification.message.lower()
            assert 'Administrator rejected' in manager_notification.message
            assert employee_user.username in manager_notification.message
        else:
            print("❌ No manager notification found!")
            return False

        # Check that the request status was updated
        leave_request.refresh_from_db()
        if leave_request.status == 'rejected':
            print(f"✅ Leave request status updated to: {leave_request.status}")
        else:
            print(f"❌ Leave request status not updated. Current status: {leave_request.status}")
            return False

        print("🎉 All tests passed! Admin reject notifications are working correctly.")
        return True

    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = test_admin_reject_notifications()
    if success:
        print("\n✅ Admin reject notification test completed successfully!")
        sys.exit(0)
    else:
        print("\n❌ Admin reject notification test failed!")
        sys.exit(1)
