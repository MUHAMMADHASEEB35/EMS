#!/usr/bin/env python
import os
import sys
import django

# Add the project directory to the Python path
sys.path.append('g:/portalproject')
os.chdir('g:/portalproject')

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'employee_portal.settings')
django.setup()

from employee_portal.portal.models import User, Notification
from django.contrib.auth import get_user_model
from django.test import Client

User = get_user_model()

try:
    print("🔍 Testing Notification System...")

    # Get the first user
    user = User.objects.first()
    if not user:
        print("❌ No users found in the system")
        sys.exit(1)

    print(f"👤 Testing with user: {user.username}")

    # Create a test notification
    notification = Notification.objects.create(
        user=user,
        notification_type='info',
        title='Test Notification',
        message='This is a test notification to verify the system is working.',
        is_read=False
    )
    print(f"✅ Created test notification (ID: {notification.id})")

    # Test the notification count
    unread_count = Notification.objects.filter(user=user, is_read=False).count()
    print(f"🔔 Unread notifications: {unread_count}")

    # Test the API endpoint
    client = Client()
    # Try to login (this might fail if we don't know the password)
    try:
        # Check if we can access the notifications endpoint without authentication first
        response = client.get('/portal/notifications/')
        print(f"🌐 API Response Status: {response.status_code}")

        if response.status_code == 200:
            data = response.json()
            print(f"📊 Notifications returned: {len(data.get('notifications', []))}")
            print("✅ Notification API is working!")
        elif response.status_code == 302:
            print("🔒 Authentication required (expected)")
            print("✅ Notification URLs are properly configured!")
        else:
            print(f"❌ API Error: {response.content}")

    except Exception as e:
        print(f"❌ API Test Error: {e}")

    print("🎯 Notification system test completed!")

except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
